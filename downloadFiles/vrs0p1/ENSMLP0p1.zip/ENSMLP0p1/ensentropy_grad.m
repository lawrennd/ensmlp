function g = ensentropy_grad(net, x)

% ENSENTROPY_GRAD Entropy term's gradient.
%
%	Description:
%
%	G = ENSENTROPY_GRAD(NET, X) returns the gradient of the entropy
%	part.
%	 Returns:
%	  G - the gradient of the entropy portion.
%	 Arguments:
%	  NET - the network for which gradient is required.
%	  X - input locations.
%	
%
%	See also
%	ENSGRAD, ENSPRIOR_GRAD


%	Copyright (c) 1999 Neil D. Lawrence
% 	ensentropy_grad.m version 1.1

  
gnet = net;

% Terms that are not involved in the gradient 
gnet.w1 = zeros(size(net.w1));
gnet.b1 = zeros(size(net.b1));
gnet.w2 = zeros(size(net.w2));
gnet.b2 = zeros(size(net.b2));

% Check for type none to avoid inverse of zero matrix
if strcmp(net.covstrct , 'none')
  g = enspak(gnet);
  return
end

[Iuu, Ivv, Iuv] = ensinv(net);
ndata = size(x, 1);


d1 = diag(Iuu)'.*[net.d1(:)' net.db1];
mark1 = net.nin*net.nhidden;
gnet.d1 = reshape(d1(1:mark1), net.nin, net.nhidden);
mark2 = mark1 + net.nhidden;
gnet.db1 = reshape(d1(mark1+1:mark2), 1, net.nhidden);
d2 = diag(Ivv)'.*[net.d2(:)' net.db2];
mark1 = net.nhidden*net.nout;
gnet.d2 = reshape(d2(1:mark1), net.nhidden, net.nout);
mark2 = mark1 + net.nout;
gnet.db2 = reshape(d2(mark1+1:mark2), 1, net.nout);

switch net.covstrct
 case 'diag' 
  % do nothing  
 otherwise 
  error('Covariance function not yet implemented')
end

g = enspak(gnet);
  


