function [y, sampweights] = mixenssamp(net, x, nsamps)

% MIXENSSAMP Sample from the posterior distribution
%
%	Description:
%
%	[Y, SAMPWEIGHTS] = MIXENSSAMP(NET, X, NSAMPS) takes a sample from
%	the posterior distribution of the weights and generates ouputs Y for
%	the specified inputs X
%	 Returns:
%	  Y - the output sample locations.
%	  SAMPWEIGHTS - the weights used to give the samples.
%	 Arguments:
%	  NET - input network.
%	  X - input locations.
%	  NSAMPS - number of samples.
%	
%
%	See also
%	ENSFWD, ENSUNPAK, ENSSAMP


%	Copyright (c) 1998, 1999 Neil D. Lawrence
% 	mixenssamp.m version 1.1

	
errstring = consist(net, 'mixens', x);
if ~isempty(errstring);
  error(errstring);
end

selectmode = rand(1, nsamps);
selectmode = selectmode*net.M;

for i = 1:net.M
  index = find(selectmode>=(i-1) & selectmode<i);
  nsampsM = length(index);
  [Cuu, Cvv, Cuv] = enscovar(net.ens(i));
  C = [Cuu Cuv; Cuv' Cvv];
  covstrct = net.ens(i).covstrct;
  net.ens(i).covstrct = 'none';
  weights = enspak(net.ens(i));
  sampweights = gsamp(weights, C, nsampsM);
  for j = 1:nsampsM
    sampnet = ensunpak(net.ens(i), sampweights(j, :));
    y(:, index(j)) = ensfwd(sampnet, x);
  end

end
