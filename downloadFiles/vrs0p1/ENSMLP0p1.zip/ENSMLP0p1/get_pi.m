function [init] = get_pi(z)

% GET_PI Function to get pi given the exp parameter z.
%
%	Description:
%
%	PI = GET_PI(Z) returns lambda given the exponential parameter z.
%	 Returns:
%	  PI - the output of the softmax.
%	 Arguments:
%	  Z - the argument of the exponential.
%	
%
%	See also
%	GET_LAMBDA


%	Copyright (c) 1998 Mehdi Azzouzi
% 	get_pi.m version 1.2



z =z - max(z);
init = exp(z) ./ sum(exp(z));
