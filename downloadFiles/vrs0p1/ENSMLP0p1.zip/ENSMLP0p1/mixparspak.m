function p = mixparspak(net)

% MIXPARSPAK Combines the mixture distribution parameters into one vector.
%
%	Description:
%
%	W = MIXPARSPAK(NET) combines the mixture distribution parameters
%	into one vector.
%	 Returns:
%	  W - the parameters extracted from the network.
%	 Arguments:
%	  NET - the network to extract parameters from.
%	
%	
%
%	See also
%	MIXPARS, MIXPARSERR, MIXPARSGRAD


%	Copyright (c) 1998, 1999 Neil D. Lawrence and Mehdi Azzouzi


%	Based on code by Christopher M Bishop and Ian T Nabney Copyright (c) 1996, 1997
% 	mixparspak.m version 1.1

  
% Check arguments for consistency
errstring = consist(net, 'mixpars');
if ~isempty(errstring);
  error(errstring);
end

M = net.M;

% Pak the mixing and lambda coefficients
p = [net.y];
% For each component pak the mixture and the smooth distributions
for m = 1:M
  p = [p smoothpak(net.smooth(m))];
end




