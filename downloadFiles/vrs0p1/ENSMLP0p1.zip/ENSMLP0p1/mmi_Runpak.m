function net = mmi_Runpak(net, w)

% MMI_RUNPAK Place parameters of smoothing distribution in a network.
%
%	Description:
%
%	NET = MMI_RUNPAK(NET, W) extracts the parameters of the smoothing
%	distributions from the network in preparation for optimisation.
%	 Returns:
%	  NET - the network containing the smoothing distributions.
%	 Arguments:
%	  NET - the network containing the smoothing distributions.
%	  W - the parameters of the smoothing distributions.
%	
%
%	See also
%	MMI_RERR, MMI_RGRAD, MMI_RUNPAK, MIXENS


%	Copyright (c) 1998, 1999 Mehdi Azzouzi and Neil D. Lawrence
% 	mmi_Runpak.m version 1.2

  
errstring = consist(net, 'mmi_R');
if ~isempty(errstring);
  error(errstring);
end

M = net.M;

% Unpak the mixing and lambda coeff
if strcmp(net.soft, 'y') == 1
  net.z = w(1:M);
  net.y = w(M+1:2*M);
  mark1 = 2*M+1;
else
  net.y = w(1:M);
  mark1 = M+1;
end

% For each component unpak the mixture and the smooth distributions
for m = 1:M
  net.smooth(m) = smoothunpak(net.smooth(m), w(mark1:mark1+net.smooth(m).npars-1));
  mark1 = mark1 + net.smooth(m).npars;
end




