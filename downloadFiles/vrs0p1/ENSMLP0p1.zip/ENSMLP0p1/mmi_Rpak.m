function p = mmi_Rpak(net)

% MMI_RPAK Extract parameters of smoothing distributions from network.
%
%	Description:
%
%	W = MMI_RPAK(NET) extracts the parameters of the smoothing
%	distributions from the network in preparation for optimisation.
%	 Returns:
%	  W - the parameters of the smoothing distributions.
%	 Arguments:
%	  NET - the network containing the smoothing distributions.
%	
%
%	See also
%	MMI_RERR, MMI_RGRAD, MMI_RUNPAK, MIXENS


%	Copyright (c) 1998, 1999 Mehdi Azzouzi and Neil D. Lawrence
% 	mmi_Rpak.m version 1.1


% Check arguments for consistency

errstring = consist(net, 'mmi_R');
if ~isempty(errstring);
  error(errstring);
end

M = net.M;

% Pak the mixing and lambda coefficients
if strcmp(net.soft, 'y') == 1
  p = [net.z net.y];
else
  p = [net.y];
end

% For each component pak the mixture and the smooth distributions
for m = 1:M
  p = [p smoothpak(net.smooth(m))];
end




