function p = mixenspak(net)

% MIXENSPAK Takes parameters from structure and places in a vector.
%
%	Description:
%
%	W = MIXENSPAK(NET) takes a network data structure NET and combines
%	the component weight matrices bias vectors into a single row vector
%	P.
%	 Returns:
%	  W - the parameters extracted from the network.
%	 Arguments:
%	  NET - the network to extract parameters from.
%	
%	
%
%	See also
%	MIXENS, SMOOTHPAK, MIXENSERR, MIXENSGRAD


%	Copyright (c) 1998, 1999 Neil D. Lawrence and Mehdi Azzouzi


%	Based on code by Christopher M Bishop and Ian T Nabney Copyright (c) 1996, 1997
% 	mixenspak.m version 1.1


% Check arguments for consistency

errstring = consist(net, 'mixens');
if ~isempty(errstring);
  error(errstring);
end

M = net.M;

% Pak the mixing and lambda coefficients
if strcmp(net.soft, 'y') == 1
  p = [net.z net.y];
else
  p = [net.y];
end

% For each component pak the mixture and the smooth distributions
for m = 1:M
  p = [p enspak(net.ens(m)) smoothpak(net.smooth(m))];
end




