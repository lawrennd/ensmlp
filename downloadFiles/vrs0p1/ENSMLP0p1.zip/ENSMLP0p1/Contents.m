% ENSMLP toolbox
% Version 0.1		25-Dec-2007
% Copyright (c) 2007, Neil D. Lawrence
% 
, Neil D. Lawrence
% SUMDET Computes the determinant of (I+Q*inv(R))
% SMOOTHCOVINV Combines the parameters mu and d for the inverse covariance.
% GET_LAMBDA Function to get lambda given the exp parameter z.
% MIXENSUNPAK Distribute parameters in W across the NET structure.
% ENSERR Evaluate error function for 2-layer ensemble network.
% MMIGRAD Computes the gradient of the MI with respect to the parameters of the net
% ENSHESS Evaluate the Hessian matrix for a multi-layer perceptron network.
% ENSPAK Takes parameters from structure and places in a vector.
% DEMTECATORMIXENSGROUP Learn Tecator with mixture of ensembles and grouped prior.
% DEMTECATORENSGROUP Demonstrate Ensemble with group prior on Tecator data set.
% ENSHYPERPRIOR Create gamma priors for hyperparameters in ensmeble learning.
% MMI_RERR Wrapper function for the mixture mutual information bound.
% GAMMAENTROPY The entropy of a gamma distribution.
% MIXENSRMNODE Remove a node from the network.
% DEMTECATORGPRBFARD Demonstrate GP with RBF ARD prior on Tecator data set.
% MIXHYPERGRADCHEK Check gradient of hyper parameters.
% ENSHDOTV Evaluate the product of the data Hessian with a vector. 
% MIXENSSAMP Sample from the posterior distribution
% MMI_RUNPAK Place parameters of smoothing distribution in a network.
% MIXENSERR Evaluate error function for 2-layer mixtures of ensemble network.
% ENSADDNODE Add a node to a ENS structure.
% MIXENSUPDATEHYPERPAR Re-estimate parameters of the hyper posteriors.
% ENSENTROPY_GRAD Entropy term's gradient.
% INIT_R initialises the smoothing distributions
% ENSUPDATEHYPERPAR Re-estimate parameters of the hyper posteriors.
% MIXENSPAK Takes parameters from structure and places in a vector.
% SMOOTH Create the smoothing distribtuions for the mutual information bound.
% ENSDATA_ERROR Error of the data portion.
% MIXENSLLL Evaluate lowerbound on likelihood for ensemble learning mixtures.
% SMOOTHRMNODE Remove a node from the smoothing distribution.
% MMI_RPAK Extract parameters of smoothing distributions from network.
% MIXENS Initialises a neural net for ensemble learning with a mixture.
% ENSHYPERMOMENTS Re-estimate moments of the hyperparameters.
% ENSENTROPY_ERROR Entropy term's contribution to the error.
% MIXPARSUNPAK Distribute mixture parameters in W across the NET structure.
% ENSUNPAK Distribute parameters in W across the NET structure.
% ENSCOVAR Combines the parameters mu and d to produce the covariance matrix.
% MIXENSHYPERMOMENTS Re-estimate moments of the hyperparameters for the ensemble mixtures.
% MIXENSGRAD Evaluate gradient of error function for 2-layer mixture ensemble network.
% DEMTECATORMIXENSNRD Demonstrate Ensemble with NRD on Tecator data set.
% ENSOUTPUTEXPEC gives the expectation of the output function and its square.
% ENSLEARN Learn an ensemble neural network from data.
% ENSPRIOR_GRAD Prior term's gradient.
% ENSDATA_GRAD Gradient of the data portion.
% DEMTECATORENSNRD Demonstrate Ensemble with NRD on Tecator data set.
% TRACEQR Computes the trace of (Q*inv(R))
% DISTR Computes the distance with respect to R
% SMOOTHUNPAK Distribute smoothing parameters in W across the NET structure.
% EVIDLEARN Learn an evidence procedure neural network from data.
% ENSLLL Evaluate lowerbound on likelihood for ensemble learning.
% GET_PI Function to get pi given the exp parameter z.
% MMI The bound on the mutual information term from a mixture of Gaussians.
% ENSFWD Forward propagation through 2-layer network.
% ENSGRAD Evaluate gradient of error function for 2-layer ensemble network.
% ENSDERIV Evaluate derivatives of network outputs with respect to weights.
% PRIORINVCOV Returns the diagonal of the inverse covariance matrix of the prior
% MIXENSLEARN Learn a mixture nsemble neural network from data.
% MIXENSMIXMSTEP re-estimate the mixing coefficients of the mixture.
% DISTSUM Computes the distance with respect to R
% ENSPRIOR_ERROR The prior term's portion of the error.
% ENSRMNODE Remove a node from the network.
% MIXENSOUTPUTEXPEC for each component gives the expectation of the output.
% ENSEXPGRAD expectation of the gradient.
% MIXPARSPAK Combines the mixture distribution parameters into one vector.
% MIXPARSERR Portion of error function associated with mixture parameters.
% ENSINV Combines the parameters mu and d for the inverse covariance.
% MMI_RGRAD Wrapper function for the mixture mutual information gradient.
% ENSMLPTOOLBOXES Load in required toolboxes for ENSMLP.
% ENS Create a 2-layer feedforward network for ensemble learning
% SMOOTHPAK Combines the smoothing distribution parameters into one vector.
% MIXPARSGRAD Gradient of error function with respect to mixture parameters.
% SMOOTHCOVAR Combines the parameters mu and d to produce the covariance matrix.
