function [l] = get_lambda(z)

% GET_LAMBDA Function to get lambda given the exp parameter z.
%
%	Description:
%
%	LAMBDA = GET_LAMBDA(Z) returns lambda given the exponential
%	parameter z.
%	 Returns:
%	  LAMBDA - the output of the exponential.
%	 Arguments:
%	  Z - the argument of the exponential.
%	
%
%	See also
%	GET_PI


%	Copyright (c) 1998 Mehdi Azzouzi
% 	get_lambda.m version 1.1

  
z = z.*(z<7e2)+(7e2*(z>=7e2));
l = exp(z);
