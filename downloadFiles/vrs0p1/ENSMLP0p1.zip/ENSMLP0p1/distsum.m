function [dist, vecQ, vecR, diff_vecQ_vecR] = distsum(ensQ, smoothR, suminv)

% DISTSUM Computes the distance with respect to R
%
%	Description:
%
%	DIST = DISTSUM(ENSQ, SMOOTHR, SUMINV) computes the Mahalanobis
%	distance for R.
%	 Returns:
%	  DIST - the mahalobis distrance.
%	 Arguments:
%	  ENSQ - ensemble learning distribution ~ N(vecQ, Q)
%	  SMOOTHR - smoothing distribution ~ N(vecR, R)
%	  SUMINV - 
%	
%
%	See also
%	DISTR, MMI, MIXENSMIXMSTEP


%	Copyright (c) 1998, 1999 Mehdi Azzouzi
% 	distsum.m version 1.1



% Extract the means of Q and R
vecQ = [ensQ.w1(:); ensQ.b1'; ensQ.w2(:); ensQ.b2'];
vecR = [smoothR.w1(:); smoothR.b1'; smoothR.w2(:); smoothR.b2'];
diff_vecQ_vecR = vecQ - vecR;

% Compute the distance with respect to R distribution
dist = (diff_vecQ_vecR)' * suminv * (diff_vecQ_vecR);
