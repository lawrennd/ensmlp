function [e, E_D, eprior, entropy] = enserr(net, x, t, flag)

% ENSERR Evaluate error function for 2-layer ensemble network.
%
%	Description:
%
%	E = ENSERR(NET, X, T) takes a network data structure NET together
%	with a matrix X of input vectors and a matrix T of target vectors,
%	and evaluates the error function E. The error function is the
%	negative of a lowerbound on the log likelihood. It is the negative
%	log likelihood plus the Kullback Leibler divergence between the
%	Gaussian represented by the network and the true posterior
%	probability of the weights given the data.
%	 Returns:
%	  E - the error on the data.
%	 Arguments:
%	  NET - the network for which error is required.
%	  X - the input data.
%	  T - the target data.
%	DESC also returns the
%	data, prior and entropy components of the total error.
%	RETURN E : total error.
%	RETURN EDATA : data error.
%	RETURN EPRIOR : prior error.
%	RETURN ENTROPY : entropy error.
%	
%	
%	
%
%	See also
%	ENS, ENSPAK, ENSUNPAK, ENSFWD, ENSGRAD


%	Copyright (c) 1998 Neil D. Lawrence


%	Based on code by Christopher M Bishop and Ian T Nabney Copyright (c) 1996, 1997
% 	enserr.m version 1.1

  
% Check arguments for consistency


% Evaluate the prior contribution to the error.

switch net.covstrct
 case 'none'
  y = ensoutputexpec(net, x);
  E_D = 0.5*sum(sum((y - t).^2));
  if isfield(net, 'beta')
    e1 = net.beta*E_D;
  else
    e1 = E_D;
  end
  if isfield(net, 'alpha')
    w = enspak(net);
    if size(net.alpha) == [1 1]
      eprior = 0.5*(w*w');
      e2 = eprior*net.alpha;
    else
      eprior = 0.5*(w.^2)*net.alphaposterior.index;
      e2 = eprior*net.alpha;
    end
  else
    eprior = 0;
    e2 = 0;
  end
  e = e1 + e2;  
 otherwise
  if nargin == 4
    [e1, E_D] = ensdata_error(net, x, t, 'beta', flag);
  else
    [e1, E_D] = ensdata_error(net, x, t, 'beta');
  end
  eprior = ensprior_error(net);
  entropy = ensentropy_error(net);
  e = e1 + eprior - entropy;  
end
