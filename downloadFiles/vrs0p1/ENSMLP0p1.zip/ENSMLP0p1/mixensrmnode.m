function net = mixensrmnode(net, row, nodes);

% MIXENSRMNODE Remove a node from the network.
%
%	Description:
%
%	MIXENSRMNODE(NET, ROW, NODES) removes a node from the network.
%	 Arguments:
%	  NET - the network from which the nodes will be removed.
%	  ROW - the row from which to remove the nodes.
%	  NODES - the nodes to remove.
%	
%
%	See also
%	MIXENS


%	Copyright (c) 1999 Neil D. Lawrence
% 	mixensrmnode.m version 1.1


for m = 1:net.M
  net.smooth(m) = smoothrmnode(net.smooth(m), row, nodes);
  net.ens(m) = ensrmnode(net.ens(m), row, nodes);
end
net.nwts = net.ens(1).nwts;
net.npars = net.ens(1).npars;
net.nhidden = net.ens(1).nhidden;
