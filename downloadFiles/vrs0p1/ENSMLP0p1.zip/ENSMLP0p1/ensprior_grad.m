function g = ensprior_grad(net)

% ENSPRIOR_GRAD Prior term's gradient.
%
%	Description:
%
%	G = ENSPRIOR_GRAD(NET, X) returns the gradient of the prior part.
%	 Returns:
%	  G - the gradient of the prior portion.
%	 Arguments:
%	  NET - the network for which gradient is required.
%	  X - input locations.
%	
%
%	See also
%	ENSGRAD, ENSENTROPY_GRAD


%	Copyright (c) 1999 Neil D. Lawrence
% 	ensprior_grad.m version 1.1


if isfield(net, 'alpha')
  w = enspak(net);
  A = priorinvcov(net);    
  
  switch net.covstrct    
  case 'none'
    g = [A'.*w(1:net.nwts)];
    
  case 'diag'       
    g = [A'.*w(1:net.nwts), A'.*w(net.nwts+(1:net.nwts))];
    
  case 'noded'
    error('Code for noded not yet implemented')
      %g = net.alpha* ...
      %[w(1:ndet.nwts) 2*w((net.nwts+1):net.npars)];
  
  case 'layered'      
    error('Code for layered not yet implemented')
    
  case 'full'
      error('Code for full not yet implemented')
	
  end 
else
  g = 0;
end
