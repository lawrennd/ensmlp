function net = mixparsunpak(net, w)

% MIXPARSUNPAK Distribute mixture parameters in W across the NET structure.
%
%	Description:
%
%	NET = MIXPARSUNPAK(NET, W) takes a paked mixture parameters
%	contained in W and distributes it across a NET.
%	 Returns:
%	  NET - the network with the parameters distributed.
%	 Arguments:
%	  NET - the net structure in which to distribute parameters.
%	  W - the parameters to distribute.
%	
%	
%
%	See also
%	MIXENS, MIXPARSERR, MIXPARSPAK


%	Copyright (c) 1998, 1999 Neil D. Lawrence and Mehdi Azzouzi


%	Based on code by Christopher M Bishop and Ian T Nabney Copyright (c) 1996, 1997
% 	mixparsunpak.m version 1.1


errstring = consist(net, 'mixpars');
if ~isempty(errstring);
  error(errstring);
end

M = net.M;

% Unpak the mixing and lambda coeff
%net.z = w(1:M);
%net.y = w(M+1:2*M);
%mark1 = 2*M+1;
net.y = w(1:M);
mark1 = M+1;
% For each component unpak the mixture and the smooth distributions
for m = 1:M
  net.smooth(m) = smoothunpak(net.smooth(m), w(mark1:mark1+net.smooth(m).npars-1));
  mark1 = mark1 + net.smooth(m).npars;
end




