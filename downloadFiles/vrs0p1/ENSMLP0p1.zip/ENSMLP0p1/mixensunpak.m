function net = mixensunpak(net, w)

% MIXENSUNPAK Distribute parameters in W across the NET structure.
%
%	Description:
%
%	NET = MIXENSUNPAK(NET, W) takes a paked mixture of ensemble learning
%	contained in W and distributes it across a NET.
%	 Returns:
%	  NET - the network with the parameters distributed.
%	 Arguments:
%	  NET - the net structure in which to distribute parameters.
%	  W - the parameters to distribute.
%	
%	
%
%	See also
%	MIXENS, SMOOTHUNUNPAK, ENSFWD, ENSERR, ENSBKP, ENSGRAD


%	Copyright (c) 1998, 1999 Neil D. Lawrence and Mehdi Azzouzi


%	Based on code by Christopher M Bishop and Ian T Nabney Copyright (c) 1996, 1997
% 	mixensunpak.m version 1.1

  
% Check arguments for consistency
errstring = consist(net, 'mixens');
if ~isempty(errstring);
  error(errstring);
end

M = net.M;

% Unpak the mixing and lambda coeff
if strcmp(net.soft, 'y') == 1
  net.z = w(1:M);
  net.y = w(M+1:2*M);
  mark1 = 2*M+1;
else
  net.y = w(1:M);
  mark1 = M+1;
end

% For each component unpak the mixture and the smooth distributions
for m = 1:M
  net.ens(m) = ensunpak(net.ens(m), w(mark1:mark1+net.ens(m).npars-1));
  mark1 = mark1 + net.ens(m).npars;
  net.smooth(m) = smoothunpak(net.smooth(m), w(mark1:mark1+net.smooth(m).npars-1));
  mark1 = mark1 + net.smooth(m).npars;
end




