function net = mixenshypermoments(net)

% MIXENSHYPERMOMENTS Re-estimate moments of the hyperparameters for the ensemble mixtures.
%
%	Description:
%
%	NET = MIXENSHYPERMOMENTS(NET) re-estimates the moments of the
%	hyperparameters ALPHA and BETA under the hyperposterior.
%	 Returns:
%	  NET - the net with the moments updated.
%	 Arguments:
%	  NET - the input net.
%	
%
%	See also
%	ENSHYPERPRIOR, ENSGRAD, ENSERR, DEMENS1


%	Copyright (c) 1999 Neil D Lawrence and Mehdi Azzouzi
% 	mixenshypermoments.m version 1.1


net.ens(1).alpha = net.ens(1).alphaposterior.a./net.ens(1).alphaposterior.b;
net.ens(1).lnalpha = psi(net.ens(1).alphaposterior.a) ...
    - log(net.ens(1).alphaposterior.b);
net.ens(1).beta = net.ens(1).betaposterior.a./net.ens(1).betaposterior.b;
net.ens(1).lnbeta = psi(net.ens(1).betaposterior.a) ...
    - log(net.ens(1).betaposterior.b); 
for m = 2:net.M
  net.ens(m).alpha = net.ens(1).alpha;
  net.ens(m).lnalpha = net.ens(1).lnalpha;
  net.ens(m).beta = net.ens(1).beta;
  net.ens(m).lnbeta = net.ens(1).lnbeta;
end












