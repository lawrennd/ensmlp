function lll = mixenslll(net, x, t)

% MIXENSLLL Evaluate lowerbound on likelihood for ensemble learning mixtures.
%
%	Description:
%
%	LLL = MIXENSLLL(NET, X, T) takes a network data structure NET
%	together with a matrix X of input vectors and a matrix T of target
%	vectors, and evaluates the error function E. The error function is
%	the negative of a lowerbound on the log likelihood. It is the
%	negative log likelihood plus the Kullback Leibler divergence between
%	the Gaussian represented by the network and the true posterior
%	probability of the weights given the data.
%	 Returns:
%	  LLL - lower bound on log likelihood.
%	 Arguments:
%	  NET - network for which likelihood is required.
%	  X - input data.
%	  T - target data.
%	
%
%	See also
%	MIXENS, MIXENSPAK, MIXENSUNPAK, MIXENSFWD, MIXENSGRAD


%	Copyright (c) 1999 Neil D. Lawrence and Mehdi Azzouzi
% 	mixenslll.m version 1.1


lll = enslll(net.ens(1), x, t, mixenserr(net, x, t));
