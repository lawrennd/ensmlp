function [sexp, qexp] = mixensoutputexpec(net, x)

% MIXENSOUTPUTEXPEC for each component gives the expectation of the output.
%
%	Description:
%
%	[Y, Y2EXP] = MIXENSOUTPUTEXPEC(NET, X) gives the expectation of the
%	output function associated with each component and its square.
%	 Returns:
%	  Y - the expected output associated with the given input.
%	  Y2EXP - the expectation of the square of the ouptut.
%	 Arguments:
%	  NET - the network from which the expectations are taken.
%	  X - the input locations for which the outputs are desired.
%	
%
%	See also
%	ENSOUTPUTEXPEC


%	Copyright (c) 1998, 1999 Neil D. Lawrence
% 	mixensoutputexpec.m version 1.1


qexp = zeros(size(x, 1), net.ens(1).nout);
sexp = zeros(size(x, 1), net.ens(1).nout);

% Check the type of softmax
if strcmp(net.soft, 'y') == 1
  mixing_coeff = get_pi(net.z);
else
  mixing_coeff = net.pi;
end
  
for m = 1:net.M
  [compsexp, compqexp] = ensoutputexpec(net.ens(m), x);
  sexp = sexp + mixing_coeff(m)*compsexp;
  qexp = qexp + mixing_coeff(m)*compqexp;
end
