function [net, gamma]  = evidlearn(nhidden, x, t, prior, beta, ...
				   rseed, dataset, niters)

% EVIDLEARN Learn an evidence procedure neural network from data.
%
%	Description:
%
%	NET = EVIDLEARN(NHIDDEN, X, ALPHAPRIOR, BETAPRIOR, RSEED,
%	DATASETNAME, NITERS) learns an evidence procedure neural network
%	give inputs and targets. The user also provides priors random seeds.
%	 Returns:
%	  NET - learnt model.
%	 Arguments:
%	  NHIDDEN - number of hiden units.
%	  X - input data.
%	  ALPHAPRIOR - prior over alphas.
%	  BETAPRIOR - prior over betas.
%	  RSEED - random seed.
%	  DATASETNAME - dataset name.
%	  NITERS - number of iterations.
%	
%
%	See also
%	ENS, ENSLLL, ENSLEARN


%	Copyright (c) 1999 Neil D. Lawrence
% 	evidlearn.m version 1.1


  % Load data and get parameters for the network
if nargin<8
  niters = 10;
end
nin = size(x, 2);
nout = size(t, 2);
inputs = 1:nin;
randn('seed', rseed)
rand('seed', rseed)

% Normalise input and output


% Generate the matrix of inputs x and targets t.
numTarget = size(t, 1);

% Set up vector of options for the optimiser.
options = zeros(1,18); 			% Default options vector.
options(1) = 1; 			% This provides display of error values
options(2) = 1.0e-7; 			% Absolute precision for weights.
options(3) = 1.0e-7; 			% Precision for objective function.
options(9) = 0;
options(14) = 500; 			% Number of training cycles in

if isstruct(prior)
  if length(prior.alpha)>4
    priortype = 'ard';
  else
    priortype = 'group';
  end
else
  priortype = 'single';
end



ninner = 10;                     % Number of innter loops.

net = mlp(nin, nhidden, nout, 'linear', prior, beta);
for k = 1:niters
  net = netopt(net, options, x, t, 'quasinew');
  [net, gamma(k)] = evidence(net, x, t, ninner);
  fprintf(1, '\nRe-estimation cycle %d:\n', k);
  fprintf(1, '  alpha =  %8.5f\n', net.alpha);
  fprintf(1, '  beta  =  %8.5f\n', net.beta);
  fprintf(1, '  gamma =  %8.5f\n\n', gamma(k));
  disp(' ')
end







