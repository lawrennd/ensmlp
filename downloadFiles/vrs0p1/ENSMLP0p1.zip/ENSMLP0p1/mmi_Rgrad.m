function g = mmi_Rgrad(net, x, t)

% MMI_RGRAD Wrapper function for the mixture mutual information gradient.
%
%	Description:
%
%	MMI_RGRAD(NET, X, T) wraps MMIGRAD to allow it to be used in
%	minimisation.
%	 Arguments:
%	  NET - input network.
%	  X - input data (not used).
%	  T - output data (not used).
%	
%
%	See also
%	MMIGRAD, MMI_RERR


%	Copyright (c) 1998, 1999 Neil D. Lawrence and Mehdi Azzouzi
% 	mmi_Rgrad.m version 1.1

  
g = -mmigrad(net, 0);