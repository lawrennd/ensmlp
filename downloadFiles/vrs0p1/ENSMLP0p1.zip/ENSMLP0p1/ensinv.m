function [I1, I2, I3] = ensinv(net)

% ENSINV Combines the parameters mu and d for the inverse covariance.
%
%	Description:
%
%	[IUU, IVV, IUV] = ENSINV(NET) combines the parameters mu and d for
%	the inverse covariance.
%	 Returns:
%	  IUU - inverse covariance for input layer.
%	  IVV - inverse covariance for output layer.
%	  IUV - cross covariance between input and ouptut layer.
%	 Arguments:
%	  NET - the network for which inverse covariance is required.
%	
%
%	See also
%	ENS, ENSUNPAK, ENSFWD, ENSERR, ENSBKP, ENSGRAD, ENSCOVAR


%	Copyright (c) 1999 Neil D. Lawrence
% 	ensinv.m version 1.1

  
% Check arguments for consistency
errstring = consist(net, 'ens');
if ~isempty(errstring);
  error(errstring);
end

tnin = net.nin + 1;
tnhidden = net.nhidden + 1;

[Cuu, Cvv, Cuv] = enscovar(net);

nw1 = net.nhidden*(net.nin);
nw2 = net.nhidden*net.nout;
nb1 = net.nhidden;
nb2 = net.nout;
np1 = nw1 + nb1;
np2 = nw2 + nb2;

switch net.covstrct

  case 'none'
    I1 = diag(np1)*inf;
    I2 = diag(np2)*inf;
    I3 = zeros(np1, np2);

case 'diag'
  
  I3 = zeros(np1, np2);
  I1 = diag(ones(1, np1)./([net.d1(:)'.^2 net.db1.^2]));	
  I2 = diag(ones(1, np2)./([net.d2(:)'.^2 net.db2.^2]));	

otherwise
  error('Covariance function not yet implemented.')
  
end







