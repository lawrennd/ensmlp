function H=gammaentropy(a, b)

% GAMMAENTROPY The entropy of a gamma distribution.
%
%	Description:
%	
% 	gammaentropy.m version 1.1

  
H = -((a-1).*digamma(a) + log(b) - a - gammaln(a));
