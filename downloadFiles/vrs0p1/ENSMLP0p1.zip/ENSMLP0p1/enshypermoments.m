function net = enshypermoments(net)

% ENSHYPERMOMENTS Re-estimate moments of the hyperparameters.
%
%	Description:
%
%	NET = ENSHYPERMOMENTS(NET) re-estimates the moments of the
%	hyperparameters ALPHA and BETA under the hyperposterior.
%	 Returns:
%	  NET - the net with the moments updated.
%	 Arguments:
%	  NET - the input net.
%	
%
%	See also
%	ENSHYPERPRIOR, ENSGRAD, ENSERR, DEMENS1


%	Copyright (c) 1999 Neil D Lawrence and Mehdi Azzouzi
% 	enshypermoments.m version 1.1


net.alpha = net.alphaposterior.a./net.alphaposterior.b;
net.lnalpha = digamma(net.alphaposterior.a) - log(net.alphaposterior.b);
net.beta = net.betaposterior.a./net.betaposterior.b;
net.lnbeta = digamma(net.betaposterior.a) - log(net.betaposterior.b); 













