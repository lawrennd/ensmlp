function err = mmi_Rerr(net, x, t)

% MMI_RERR Wrapper function for the mixture mutual information bound.
%
%	Description:
%
%	MMI_RERR(NET, X, T) wraps MMI to allow it to be minimised.
%	 Arguments:
%	  NET - input network.
%	  X - input data (not used).
%	  T - output data (not used).
%	
%
%	See also
%	MMI, MMI_RGRAD


%	Copyright (c) 1998, 1999 Neil D. Lawrence and Mehdi Azzouzi
% 	mmi_Rerr.m version 1.1

  
err = -mmi(net);