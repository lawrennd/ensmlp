function [tr, CovarQ, CovarR, InverseR] = traceQR(ensQ, smoothR, CovarQ, InverseR)

% TRACEQR Computes the trace of (Q*inv(R))
%
%	Description:
%
%	TR = TRACEQR(ENSQ, SMOOTHR, COVARQ, INVERSER) Computes the trace of
%	Q*inv(R) and returns some parameters needed in other codes.
%	 Returns:
%	  TR - trace of Q*inv(R). See also: SEEALSO : mmi, mixensmixmstep
%	 Arguments:
%	  ENSQ - is an ensemble learning distribution ~ N(vecQ, Q)
%	  SMOOTHR - is a smooth distribution ~ N(vecR, R)
%	  COVARQ - 
%	  INVERSER - 


%	Copyright (c) 1998, 1999 Mehdi Azzouzi and Neil D Lawrence
% 	traceQR.m version 1.1

  
% Get the trace
switch smoothR.covstrct
 case 'diag'
  tr = sum(diag(CovarQ).*diag(InverseR));
 otherwise
  % Should be sum(sum(CovarQ.*InverseR)) for efficiency.
  tr = trace(CovarQ*InverseR);
end