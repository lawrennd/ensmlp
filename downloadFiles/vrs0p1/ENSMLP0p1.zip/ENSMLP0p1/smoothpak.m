function p = smoothpak(net)

% SMOOTHPAK Combines the smoothing distribution parameters into one vector.
%
%	Description:
%
%	W = SMOOTHPAK(NET) combines the smoothing distribution parameters
%	into one vector.
%	 Returns:
%	  W - the parameters extracted from the network.
%	 Arguments:
%	  NET - the network to extract parameters from.
%	
%	
%
%	See also
%	SMOOTH, SMOOTHERR, SMOOTHGRAD


%	Copyright (c) 1998, 1999 Neil D. Lawrence and Mehdi Azzouzi


%	Based on code by Christopher M Bishop and Ian T Nabney Copyright (c) 1996, 1997
% 	smoothpak.m version 1.1

  
% Check arguments for consistency
errstring = consist(net, 'smooth');
if ~isempty(errstring);
  error(errstring);
end

switch  net.covstrct
case 'none'
  p = [net.w1(:)', net.b1, net.w2(:)', net.b2]; 

case 'diag'
  p = [net.w1(:)', net.b1, net.w2(:)', net.b2, ...
	  net.d1(:)', net.d2(:)']; 
  
case {'noded', 'unnoded'}
  p = [net.w1(:)', net.b1, net.w2(:)', net.b2, ...
	  net.d1(:)', net.d2(:)',  ...
	  net.mu1(:)', net.mu2(:)'];

case 'symmetric'
  p = [net.w1(:)', net.b1, net.w2(:)', net.b2, ...
	  net.U(:)'];
otherwise
  error('Covariance structure not yet implemented.');
end




